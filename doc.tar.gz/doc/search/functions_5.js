var searchData=
[
  ['totalskill',['totalSkill',['../main_8cpp.html#a616145f856731da53b72dcde66883135',1,'main.cpp']]]
];
