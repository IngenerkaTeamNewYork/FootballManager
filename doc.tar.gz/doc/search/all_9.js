var searchData=
[
  ['real_5fsquad',['REAL_SQUAD',['../Schemas_8h.html#a4580919b84c382598ddc92174848d256',1,'Schemas.h']]],
  ['roundobj',['RoundObj',['../classRoundObj.html',1,'RoundObj'],['../classRoundObj.html#aaa027d7af8a60a55899473d7ca88fd95',1,'RoundObj::RoundObj(const unsigned int &amp;radius, const std::string &amp;footballerName, const std::uint8_t skill, const sf::Color &amp;fillColor, const sf::Color &amp;outlineColor=sf::Color::White)'],['../classRoundObj.html#a23837bdf26e6782b0e4fa46c4cfbd815',1,'RoundObj::RoundObj(const RoundObj &amp;f)']]],
  ['roundobj_2eh',['RoundObj.h',['../RoundObj_8h.html',1,'']]]
];
