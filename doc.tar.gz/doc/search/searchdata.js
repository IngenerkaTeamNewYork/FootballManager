var indexSectionsWithContent =
{
  0: "abcfimnoprstuÐ",
  1: "rs",
  2: "cmorst",
  3: "imprst",
  4: "abcnrstu",
  5: "fÐ"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "files",
  3: "functions",
  4: "variables",
  5: "pages"
};

var indexSectionLabels =
{
  0: "Указатель",
  1: "Классы",
  2: "Файлы",
  3: "Функции",
  4: "Переменные",
  5: "Страницы"
};

