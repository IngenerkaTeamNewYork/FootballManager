var searchData=
[
  ['isnear',['isNear',['../classRoundObj.html#a00ee58e8de06da553affb11f7315ee61',1,'RoundObj']]],
  ['isoutof',['isOutOf',['../classRoundObj.html#a7507a35fdb1b62a93c55b4787fb04bf0',1,'RoundObj']]]
];
