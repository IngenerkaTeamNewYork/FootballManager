var searchData=
[
  ['ubogie_5fsquad',['UBOGIE_SQUAD',['../Schemas_8h.html#a69905190af0a2822a631f0282b09c5ee',1,'Schemas.h']]]
];
