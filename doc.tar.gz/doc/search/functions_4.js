var searchData=
[
  ['setradius',['setRadius',['../classRoundObj.html#a787c9834387b5d250b35360a868beeef',1,'RoundObj']]],
  ['setskills',['setSkills',['../classRoundObj.html#aba86ff096fa10f0a1288c889ddb0347b',1,'RoundObj::setSkills()'],['../main_8cpp.html#a3d2670f4636d5a5b402e8b281c55fb89',1,'setSkills():&#160;main.cpp']]],
  ['settexture',['setTexture',['../classRoundObj.html#a048aa55c3062d2ddfd71d4fbb3403d2e',1,'RoundObj']]]
];
