var searchData=
[
  ['scheme433',['SCHEME433',['../Schemas_8h.html#a1748649dfbc5d038aaa7cf741ac56734',1,'Schemas.h']]],
  ['scheme451',['SCHEME451',['../Schemas_8h.html#acb0979d4b3302f51997ca261a1d9b7a3',1,'Schemas.h']]],
  ['scheme532',['SCHEME532',['../Schemas_8h.html#a09ff6644fe1a3dbfdb474cf218a2f717',1,'Schemas.h']]],
  ['skill_5fgoalkeeper',['skill_goalkeeper',['../classRoundObj.html#aac4719a94e9f6405534bc43287aa7f43',1,'RoundObj']]],
  ['skillsarray',['skillsArray',['../Schemas_8h.html#a31afc9471270bb91cdea2c0bc10e7157',1,'Schemas.h']]]
];
