var searchData=
[
  ['niggaz_5fsquad',['NIGGAZ_SQUAD',['../Schemas_8h.html#aace63a86898dd292bfd6ca7c3f5d3cd0',1,'Schemas.h']]]
];
