var searchData=
[
  ['skills',['skills',['../structskills.html',1,'']]]
];
