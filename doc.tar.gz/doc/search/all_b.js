var searchData=
[
  ['team1',['Team1',['../OurTeam_8h.html#a4aeb38d2695a78709f2d9ac2b608fde6',1,'OurTeam.h']]],
  ['team2',['Team2',['../OurTeam_8h.html#a0b645cd06d599c956fced6b812c5904e',1,'OurTeam.h']]],
  ['test_2ecpp',['test.cpp',['../test_8cpp.html',1,'']]],
  ['totalskill',['totalSkill',['../main_8cpp.html#a616145f856731da53b72dcde66883135',1,'main.cpp']]]
];
